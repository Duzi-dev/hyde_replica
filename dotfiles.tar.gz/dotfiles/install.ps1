# Windows installer. Run from PowerShell in the repo folder:
#   Set-ExecutionPolicy -Scope Process Bypass; .\install.ps1

$ErrorActionPreference = 'Stop'
$repo = $PSScriptRoot

Write-Host '==> Installing packages with winget' -ForegroundColor Cyan
$packages = @(
    'Starship.Starship',
    'eza-community.eza',
    'sharkdp.bat',
    'junegunn.fzf',
    'ajeetdsouza.zoxide',
    'sxyazi.yazi',
    'Fastfetch-cli.Fastfetch',
    'DEVCOM.JetBrainsMonoNerdFont'
)
foreach ($p in $packages) {
    winget install --id $p -e --accept-source-agreements --accept-package-agreements
    if ($LASTEXITCODE -ne 0) { Write-Warning "winget could not install $p (it may already be installed)" }
}

function Link-File($src, $dest) {
    $dir = Split-Path $dest -Parent
    if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }

    if (Test-Path $dest) {
        $backup = "$dest.bak.$(Get-Date -Format yyyyMMdd-HHmmss)"
        Move-Item $dest $backup
        Write-Warning "Backed up existing $dest -> $backup"
    }

    try {
        New-Item -ItemType SymbolicLink -Path $dest -Target $src -ErrorAction Stop | Out-Null
        Write-Host "Linked $dest -> $src" -ForegroundColor Cyan
    } catch {
        # Symlinks need Developer Mode or admin; fall back to a copy
        Copy-Item $src $dest
        Write-Warning "Could not symlink, copied instead: $dest (re-run after editing the repo copy)"
    }
}

Link-File "$repo\starship\starship.toml"  "$HOME\.config\starship.toml"
Link-File "$repo\powershell\profile.ps1" $PROFILE

Write-Host ''
Write-Host 'Done. Remaining manual step:' -ForegroundColor Cyan
Write-Host '  Windows Terminal > Settings > Profiles > Defaults > Appearance > Font face: "JetBrainsMono Nerd Font"'
Write-Host 'Ghostty has no Windows build, so use Windows Terminal here (or WSL2 with install/ubuntu.sh).'
