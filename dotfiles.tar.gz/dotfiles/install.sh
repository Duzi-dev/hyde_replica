#!/usr/bin/env bash
# Detects the OS and runs the matching installer. For Windows use install.ps1.
set -euo pipefail

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [[ -r /etc/os-release ]]; then
    . /etc/os-release
fi

ids=" ${ID:-} ${ID_LIKE:-} "

if [[ -d "$HOME/.local/share/omarchy" ]] || [[ "$ids" == *" arch "* ]]; then
    exec bash "$DIR/install/omarchy.sh"
elif [[ "$ids" == *" ubuntu "* || "$ids" == *" debian "* ]]; then
    exec bash "$DIR/install/ubuntu.sh"
else
    echo "Unsupported OS (ID=${ID:-unknown}). Run the matching script in install/ by hand." >&2
    exit 1
fi
