#!/usr/bin/env bash
# Shared helpers for the install scripts.

DOTFILES_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BACKUP_SUFFIX=".bak.$(date +%Y%m%d-%H%M%S)"

info() { printf '\033[36m==>\033[0m %s\n' "$*"; }
warn() { printf '\033[33m!!\033[0m %s\n' "$*" >&2; }

# link <source in repo> <destination>
# Symlinks the file; an existing real file is moved aside first.
link() {
    local src="$1" dest="$2"

    mkdir -p "$(dirname "$dest")"

    if [[ -L "$dest" && "$(readlink -f "$dest")" == "$(readlink -f "$src")" ]]; then
        info "Already linked: $dest"
        return
    fi

    if [[ -e "$dest" || -L "$dest" ]]; then
        mv "$dest" "$dest$BACKUP_SUFFIX"
        warn "Backed up existing $dest -> $dest$BACKUP_SUFFIX"
    fi

    ln -s "$src" "$dest"
    info "Linked $dest -> $src"
}

link_dotfiles() {
    link "$DOTFILES_DIR/ghostty/config"        "$HOME/.config/ghostty/config"
    link "$DOTFILES_DIR/starship/starship.toml" "$HOME/.config/starship.toml"
    link "$DOTFILES_DIR/zsh/zshrc"             "$HOME/.zshrc"
}

set_default_shell_zsh() {
    local zsh_path
    zsh_path="$(command -v zsh || true)"
    if [[ -z "$zsh_path" ]]; then
        warn "zsh not found; skipping default shell change"
        return
    fi
    if [[ "${SHELL:-}" != "$zsh_path" ]]; then
        info "Setting zsh as your default shell (may ask for your password)"
        chsh -s "$zsh_path" || warn "chsh failed; run it manually: chsh -s $zsh_path"
    fi
}
