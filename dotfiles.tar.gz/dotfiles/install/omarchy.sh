#!/usr/bin/env bash
# Omarchy (Arch-based). Everything is in the official repos.
set -euo pipefail
source "$(dirname "${BASH_SOURCE[0]}")/lib.sh"

info "Installing packages"
sudo pacman -S --needed --noconfirm \
    ghostty zsh starship fastfetch eza bat fzf zoxide yazi \
    ttf-jetbrains-mono-nerd

link_dotfiles
set_default_shell_zsh

info "Done. Log out and back in (or open a new Ghostty window) to use zsh."
