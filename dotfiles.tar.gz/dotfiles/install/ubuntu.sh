#!/usr/bin/env bash
# Ubuntu / Debian-based. Also works inside WSL2 (skip Ghostty there).
set -euo pipefail
source "$(dirname "${BASH_SOURCE[0]}")/lib.sh"

info "Installing packages from apt"
sudo apt-get update
sudo apt-get install -y zsh curl unzip git fontconfig fzf bat zoxide

# Optional packages: not in every Ubuntu release, so don't abort if missing
for pkg in eza fastfetch; do
    sudo apt-get install -y "$pkg" || warn "$pkg is not in your apt repos; install it from its project page"
done

# Debian/Ubuntu name the binary batcat; expose it as bat
if command -v batcat >/dev/null 2>&1 && ! command -v bat >/dev/null 2>&1; then
    mkdir -p "$HOME/.local/bin"
    ln -sf "$(command -v batcat)" "$HOME/.local/bin/bat"
fi

# Starship (official installer, goes to ~/.local/bin so no sudo needed)
if ! command -v starship >/dev/null 2>&1; then
    info "Installing starship"
    mkdir -p "$HOME/.local/bin"
    curl -sS https://starship.rs/install.sh | sh -s -- -y -b "$HOME/.local/bin"
fi

# Yazi (optional)
if ! command -v yazi >/dev/null 2>&1; then
    if command -v snap >/dev/null 2>&1; then
        sudo snap install yazi --classic || warn "yazi snap install failed; see https://yazi-rs.github.io/docs/installation"
    else
        warn "yazi not installed; see https://yazi-rs.github.io/docs/installation"
    fi
fi

# JetBrainsMono Nerd Font
FONT_DIR="$HOME/.local/share/fonts/JetBrainsMonoNerdFont"
if ! fc-list | grep -qi "JetBrainsMono Nerd Font"; then
    info "Installing JetBrainsMono Nerd Font"
    tmp="$(mktemp -d)"
    curl -fsSL -o "$tmp/JetBrainsMono.zip" \
        https://github.com/ryanoasis/nerd-fonts/releases/latest/download/JetBrainsMono.zip
    mkdir -p "$FONT_DIR"
    unzip -oq "$tmp/JetBrainsMono.zip" -d "$FONT_DIR"
    rm -rf "$tmp"
    fc-cache -f
fi

# Ghostty: no official apt package, so just check for it
if ! command -v ghostty >/dev/null 2>&1; then
    warn "Ghostty is not installed. See https://ghostty.org/docs/install/binary for install options."
    warn "(On WSL2, skip Ghostty and use Windows Terminal on the Windows side.)"
fi

link_dotfiles
set_default_shell_zsh

info "Done. Open a new terminal to use zsh."
