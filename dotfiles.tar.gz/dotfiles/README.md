# dotfiles

One terminal setup for Omarchy, Ubuntu and Windows. Starship is the prompt everywhere.

| What | File | Linked to |
|---|---|---|
| Ghostty | `ghostty/config` | `~/.config/ghostty/config` |
| Starship | `starship/starship.toml` | `~/.config/starship.toml` |
| zsh | `zsh/zshrc` | `~/.zshrc` |
| PowerShell | `powershell/profile.ps1` | `$PROFILE` |

## Install

**Omarchy / Ubuntu / WSL2**

```bash
git clone <your-repo-url> ~/dotfiles
cd ~/dotfiles
./install.sh
```

**Windows** (PowerShell)

```powershell
git clone <your-repo-url> $HOME\dotfiles
cd $HOME\dotfiles
Set-ExecutionPolicy -Scope Process Bypass
.\install.ps1
```

Existing files are moved aside as `*.bak.<timestamp>`, never deleted.

## Notes

- **Machine-specific zsh settings** go in `~/.zshrc.local`, which `zsh/zshrc` loads first. It is not tracked.
- **Colors:** Omarchy's theme file overrides the fallback `theme = Catppuccin Mocha` in the Ghostty config. On other machines the fallback applies.
- **Ghostty on Windows:** no official build. Use Windows Terminal (or WSL2 plus `install/ubuntu.sh`) and set the font to `JetBrainsMono Nerd Font`.
- **Ghostty on Ubuntu:** not installed by the script. Install it separately, see https://ghostty.org/docs/install/binary
- **Omarchy-only lines** in the Ghostty config (`async-backend = epoll`, the Hyprland split-resize keybinds) are harmless elsewhere.
- **Icons:** the Nerd Font glyphs in `starship.toml` are `\u` escapes, so copying the file around can't corrupt them.
